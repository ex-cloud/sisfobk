@extends('admin.layouts.main')
@include('admin.layouts.sidebar')

@section('container')
    @yield('content')
@endsection